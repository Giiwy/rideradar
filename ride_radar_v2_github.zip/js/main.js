
document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("eventos-container");
  if (!container) return;
  container.innerHTML = `<p style="padding:1rem;background:#e7f1ff;border-left:4px solid #90c2ff;border-radius:6px;">Cargando eventos…</p>`;
  const modalidad = (container.dataset.modalidad || "todas").toLowerCase();

  // RELATIVA para GitHub Pages
  const DATA_URL = "data/eventos.json";

  try {
    const res = await fetch(DATA_URL + `?t=${Date.now()}`, { cache: "no-cache" });
    if (!res.ok) throw new Error(`HTTP ${res.status} al cargar eventos.json`);
    const eventos = await res.json();

    const filtrados = modalidad === "todas"
      ? eventos
      : eventos.filter(e => (e.modalidad || "").toLowerCase() === modalidad);

    if (!filtrados.length) {
      container.innerHTML = `<p>No hay eventos para <strong>${modalidad}</strong> ahora mismo.</p>`;
      return;
    }

    const render = (typeof window.eventoHTML === "function") ? window.eventoHTML : (e) => `
      <div class="evento ${e.modalidad || ""}">
        <h3>${e.nombre || "Evento"}</h3>
        <p><strong>Fecha:</strong> ${e.fecha || "-"}</p>
        <p><strong>Ubicación:</strong> ${e.ubicacion || "-"} (${e.provincia || "-"})</p>
        ${e.desnivel != null ? `<p><strong>Desnivel:</strong> ${e.desnivel} m</p>` : ""}
        ${e.id != null ? `<a href="detalle.html?id=${e.id}">Ver detalles</a>` : ""}
      </div>
    `;

    container.innerHTML = filtrados.map(render).join("");
  } catch (err) {
    console.error(err);
    container.innerHTML = `<p style="padding:1rem;background:#fff3cd;border-left:4px solid #ffec99;border-radius:6px;">No se pudieron cargar los eventos. Revisa que <code>${DATA_URL}</code> exista.</p>`;
  }
});
