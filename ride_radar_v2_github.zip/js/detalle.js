
document.addEventListener("DOMContentLoaded", async () => {
  const container = document.getElementById("detalle-evento");
  const params = new URLSearchParams(window.location.search);
  const id = parseInt(params.get("id"));
  if (!id) { container.innerHTML = "<p>Error: evento no encontrado.</p>"; return; }

  try {
    const res = await fetch("data/eventos.json" + `?t=${Date.now()}`, { cache: "no-cache" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const eventos = await res.json();
    const e = eventos.find(x => x.id === id);
    if (!e) { container.innerHTML = "<p>Evento no encontrado.</p>"; return; }

    container.innerHTML = `
      <article class="evento ${e.modalidad || ""}">
        <h2>${e.nombre}</h2>
        <p><strong>Fecha:</strong> ${e.fecha || "-"}</p>
        <p><strong>Ubicación:</strong> ${e.ubicacion || "-"} (${e.provincia || "-"})</p>
        ${e.desnivel != null ? `<p><strong>Desnivel:</strong> ${e.desnivel} m</p>` : ""}
        <p><strong>Modalidad:</strong> ${(e.modalidad || "").toUpperCase()}</p>
        ${e.enlace ? `<p><a href="${e.enlace}" target="_blank" rel="noopener">Enlace oficial</a></p>` : ""}
        ${e.redes?.instagram ? `<p><a href="${e.redes.instagram}" target="_blank" rel="noopener">Instagram</a></p>` : ""}
        ${e.redes?.facebook ? `<p><a href="${e.redes.facebook}" target="_blank" rel="noopener">Facebook</a></p>` : ""}
        ${e.redes?.web ? `<p><a href="${e.redes.web}" target="_blank" rel="noopener">Web</a></p>` : ""}
      </article>
    `;
  } catch (err) {
    console.error(err);
    container.innerHTML = `<p style="padding:1rem;background:#fff3cd;border-left:4px solid #ffec99;border-radius:6px;">No se pudo cargar <code>data/eventos.json</code>.</p>`;
  }
});
